# CustomClient 1.8.9 — تعليمات التشغيل

هذا مشروع Forge Mod تعليمي لـ Minecraft Java Edition 1.8.9.

## المتطلبات
- JDK 8 (Java 8)
- Gradle 2.14.1 (ملائم لـ ForgeGradle 2.1)
- IntelliJ IDEA بإصدار يدعم استيراد مشاريع Gradle القديمة
- اتصال إنترنت لتنزيل اعتماديات Forge أول مرة

## فتح المشروع
1. فك ضغط الأرشيف إلى مجلد عادي.
2. افتح المجلد `CustomClient189-Ready` من IntelliJ عبر File > Open.
3. من Settings > Build Tools > Gradle، اختر JDK 8 كـ Gradle JVM.
4. لأن هذا مشروع Forge 1.8.9 قديم، لا تستخدم Gradle 8 أو 9 معه. استخدم Gradle 2.14.1.
5. بعد مزامنة Gradle، شغّل إعداد Minecraft Client الذي يجهزه ForgeGradle، أو نفّذ `gradlew setupDecompWorkspace idea` من الطرفية إذا توفر ملف Gradle Wrapper التنفيذي.
6. للبناء، استخدم مهمة `build` ثم ابحث عن ملف JAR في `build/libs`.

## ملاحظات
- هذا Mod لـ Forge وليس تطبيق Java مستقلًا؛ لا تشغّله باستخدام `java -jar`.
- إذا لم يظهر إعداد تشغيل Minecraft تلقائيًا، جرّب من Terminal داخل مجلد المشروع: `gradle setupDecompWorkspace idea` ثم أعد فتح المشروع.
- أول بناء قد يستغرق وقتًا لأنه ينزّل Minecraft وForge والاعتماديات.
