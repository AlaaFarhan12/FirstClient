package com.customclient.module;

import com.customclient.module.movement.ToggleSprint;
import com.customclient.module.render.Fullbright;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * مدير الموديولات (Module Manager).
 * 
 * في هيكلية الكلاينت، يمثل هذا الكلاس المركز الرئيسي لإدارة دورة حياة
 * جميع الموديولات، وتسجيلها، والبحث فيها، وتمرير الأحداث (Tick, Key, Render) إليها.
 */
public class ModuleManager {

    // قائمة تخزين جميع الموديولات المسجلة في الكلاينت
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        registerModules();
    }

    /**
     * تسجيل وإضافة جميع الموديولات إلى النظام
     */
    private void registerModules() {
        System.out.println("[CustomClient] Registering Modules...");

        // موديولات الحركة
        addModule(new ToggleSprint());

        // موديولات الرسوميات
        addModule(new Fullbright());

        System.out.println("[CustomClient] Registered " + modules.size() + " modules successfully!");
    }

    /**
     * إضافة موديول للقائمة
     */
    private void addModule(Module module) {
        modules.add(module);
    }

    /**
     * إرجاع قائمة غير قابلة للتعديل الخارجي بجميع الموديولات (لحماية البيانات)
     */
    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    /**
     * البحث عن موديول بواسطة اسمه (غير حساس لحالة الأحرف Case-Insensitive)
     * 
     * @param name اسم الموديول المطلوب
     * @return كائن الموديول أو null إذا لم يوجد
     */
    public Module getModule(String name) {
        for (Module module : modules) {
            if (module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }
        return null;
    }

    /**
     * البحث عن موديول بنمطه ونوعه المباشر (Type-Safe Generic Lookup)
     * مثال للاستخدام: moduleManager.getModule(ToggleSprint.class);
     * 
     * @param clazz الكلاس المطلوب
     * @param <T> النوع المشتق من Module
     * @return نسخة الموديول أو null
     */
    @SuppressWarnings("unchecked")
    public <T extends Module> T getModule(Class<T> clazz) {
        for (Module module : modules) {
            if (module.getClass().equals(clazz)) {
                return (T) module;
            }
        }
        return null;
    }

    /**
     * تصفية الموديولات حسب تصنيف معين (مفيدة جداً لبناء الـ ClickGUI)
     * 
     * @param category التصنيف المستهدف
     * @return قائمة بالموديولات التابعة لهذا التصنيف
     */
    public List<Module> getModulesByCategory(Category category) {
        return modules.stream()
                .filter(m -> m.getCategory() == category)
                .collect(Collectors.toList());
    }

    /**
     * تمرير حدث ضغط الأزرار (Key Event) إلى الموديولات:
     * إذا تطابق الزر المضغوط مع زر الموديول، يتم تبديل حالته (Toggle).
     * 
     * @param keyCode رقم الزر في لوحة المفاتيح
     */
    public void onKeyPressed(int keyCode) {
        if (keyCode <= 0) return;

        for (Module module : modules) {
            if (module.getKeyCode() == keyCode) {
                module.toggle();
            }
        }
    }

    /**
     * تمرير حدث الـ Tick لكل موديول مفعّل
     */
    public void onTick() {
        for (Module module : modules) {
            if (module.isToggled()) {
                try {
                    module.onTick();
                } catch (Exception e) {
                    System.err.println("[CustomClient] Error updating module: " + module.getName());
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * تمرير حدث الرسم ثنائي الأبعاد (Render2D) لكل موديول مفعّل
     */
    public void onRender2D() {
        for (Module module : modules) {
            if (module.isToggled()) {
                try {
                    module.onRender2D();
                } catch (Exception e) {
                    System.err.println("[CustomClient] Error rendering module: " + module.getName());
                    e.printStackTrace();
                }
            }
        }
    }
}
