package com.customclient.module;

/**
 * تصنيفات الموديولات (Module Categories).
 * 
 * في الكلاينت، يتم تقسيم الموديولات إلى مجموعات منظمة ومحددة
 * لسهولة عرضها في الـ ClickGUI وترتيب الأكواد البرمجية.
 */
public enum Category {
    /**
     * موديولات الحركة المساعدة (مثل الجري التلقائي ToggleSprint)
     */
    MOVEMENT("حركة", "Movement"),

    /**
     * موديولات الرسوميات والإضاءة (مثل زيادة سطوع الكهوف Fullbright)
     */
    RENDER("رسوميات", "Render"),

    /**
     * موديولات واجهة المستخدم والشاشة (مثل عداد الـ FPS و CPS والإحداثيات)
     */
    HUD("الواجهة", "HUD"),

    /**
     * موديولات مساعدة للاعب في عالم اللعبة (QoL - Quality of Life)
     */
    PLAYER("اللاعب", "Player");

    private final String displayNameArabic;
    private final String displayNameEnglish;

    /**
     * منشئ التصنيف (Constructor)
     * 
     * @param displayNameArabic الاسم المعروض بالعربية في الواجهة
     * @param displayNameEnglish الاسم المعروض بالإنجليزية
     */
    Category(String displayNameArabic, String displayNameEnglish) {
        this.displayNameArabic = displayNameArabic;
        this.displayNameEnglish = displayNameEnglish;
    }

    public String getDisplayNameArabic() {
        return displayNameArabic;
    }

    public String getDisplayNameEnglish() {
        return displayNameEnglish;
    }
}
