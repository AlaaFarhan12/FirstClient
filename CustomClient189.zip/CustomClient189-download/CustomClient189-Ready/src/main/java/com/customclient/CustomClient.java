package com.customclient;

import com.customclient.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import org.lwjgl.input.Keyboard;

/**
 * الكلاس الرئيسي للكلاينت (Main Client Class).
 * 
 * يربط بين محرك Forge وأنظمة الكلاينت المخصصة:
 * - ModuleManager (إدارة الموديولات)
 * - Keybind Listener (استقبال ضغطات المفاتيح)
 * - Tick & Render Loop (دورة التحديث والرسم)
 */
@Mod(
        modid = CustomClient.MOD_ID,
        name = CustomClient.CLIENT_NAME,
        version = CustomClient.CLIENT_VERSION,
        clientSideOnly = true
)
public class CustomClient {

    public static final String MOD_ID = "customclient";
    public static final String CLIENT_NAME = "CustomClient";
    public static final String CLIENT_VERSION = "1.0.0";

    public static final String CHAT_PREFIX = EnumChatFormatting.DARK_GRAY + "[" 
            + EnumChatFormatting.AQUA + CLIENT_NAME 
            + EnumChatFormatting.DARK_GRAY + "] " + EnumChatFormatting.RESET;

    @Instance(MOD_ID)
    private static CustomClient instance;

    // مدير الموديولات
    private ModuleManager moduleManager;

    public CustomClient() {
        instance = this;
    }

    public static CustomClient getInstance() {
        return instance;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        System.out.println("==================================================");
        System.out.println("[CustomClient] Pre-Init: Initializing client core...");
        System.out.println("==================================================");
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        System.out.println("[CustomClient] Init: Initializing managers and events...");

        // 1. إنشاء وتهيئة مدير الموديولات وتسجيل كافة الموديولات الأولية
        this.moduleManager = new ModuleManager();

        // 2. تسجيل الكلاس في ناقل الأحداث (EventBus) لـ Forge للاستماع للأحداث الحية
        MinecraftForge.EVENT_BUS.register(this);

        System.out.println("[CustomClient] Init: Successfully loaded!");
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        System.out.println("[CustomClient] Post-Init: All systems operational.");
    }

    /**
     * الاستماع لحدث الضغط على أي زر في لوحة المفاتيح
     */
    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        // نتأكد من أن الزر تم ضغطه (وليس إفلاته)
        if (Keyboard.getEventKeyState()) {
            int pressedKey = Keyboard.getEventKey();
            if (pressedKey != Keyboard.KEY_NONE) {
                // تمرير المفتاح لمدير الموديولات لفحص ما إذا كان هناك موديول مربوط بهذا الزر
                moduleManager.onKeyPressed(pressedKey);
            }
        }
    }

    /**
     * الاستماع لحدث التكة (Client Tick):
     * يعمل 20 مرة في الثانية لتحديث منطق الموديولات المفعلة
     */
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        // ننفذ التحديث في نهاية التكة (PHASE.END) لضمان اكتمال حسابات محرك اللعبة
        if (event.phase == TickEvent.Phase.END && Minecraft.getMinecraft().thePlayer != null) {
            moduleManager.onTick();
        }
    }

    /**
     * الاستماع لحدث الرسم ثنائي الأبعاد على الشاشة (HUD Overlay):
     * يعمل في كل إطار (FPS) لرسم عناصر الواجهة
     */
    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        // نرسم فقط عند مرحلة الـ TEXT لتكون عناصرنا مرسومة فوق واجهة اللعبة الأصلية وبوضوح
        if (event.type == RenderGameOverlayEvent.ElementType.TEXT) {
            moduleManager.onRender2D();
        }
    }

    /**
     * حدث تجريبي: إرسال إشعار ترحيبي مع توضيح أزرار التجربة عند دخول أي عالم
     */
    @SubscribeEvent
    public void onClientConnected(FMLNetworkEvent.ClientConnectedToServerEvent event) {
        new Thread(() -> {
            try {
                Thread.sleep(1500);
            } catch (InterruptedException ignored) {}

            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer != null) {
                mc.thePlayer.addChatMessage(new ChatComponentText(
                        CHAT_PREFIX + EnumChatFormatting.GREEN + "تم تفعيل " + CLIENT_NAME + " v" + CLIENT_VERSION
                ));
                mc.thePlayer.addChatMessage(new ChatComponentText(
                        CHAT_PREFIX + EnumChatFormatting.YELLOW + "جرّب الأزرار: " 
                        + EnumChatFormatting.AQUA + "[V] ToggleSprint " 
                        + EnumChatFormatting.GRAY + "| " 
                        + EnumChatFormatting.AQUA + "[B] Fullbright"
                ));
            }
        }).start();
    }
}
