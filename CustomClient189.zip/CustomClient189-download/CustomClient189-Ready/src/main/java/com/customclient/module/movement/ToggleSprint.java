package com.customclient.module.movement;

import com.customclient.module.Category;
import com.customclient.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * موديول الجري التلقائي (ToggleSprint).
 * 
 * هذا الموديول هو ميزة راحة للاعب (Quality of Life) تتيح له الجري تلقائياً
 * دون الحاجة للضغط المستمر على زر الجري في لوحة المفاتيح.
 * 
 * المفهوم البرمجي:
 * يرث من كلاس Module، ويعيد تعريف دالة onTick للتحكم في مفتاح الجري الخاص باللعبة.
 */
public class ToggleSprint extends Module {

    /**
     * المنشئ (Constructor):
     * نحدد اسم الموديول، وصفه، تصنيفه، والمفتاح الافتراضي (مثال: حرف V).
     */
    public ToggleSprint() {
        super(
                "ToggleSprint", 
                "يبقي اللاعب في وضع الجري السريع تلقائياً أثناء التقدم للأمام", 
                Category.MOVEMENT, 
                Keyboard.KEY_V
        );
    }

    /**
     * دالة التحديث في كل تكة (onTick):
     * تعمل 20 مرة بالثانية طالما أن الموديول مفعّل.
     */
    @Override
    public void onTick() {
        // نتأكد من وجود اللاعب في العالم وعدم فتح أي قائمة (مثل المخزن Inventory أو الشات)
        if (mc.thePlayer != null && mc.currentScreen == null) {
            // إذا كان اللاعب يتحرك للأمام ولا يختفي (Sneaking) ولا يعاني من الجوع الشديد
            if (mc.thePlayer.moveForward > 0 && !mc.thePlayer.isSneaking() && mc.thePlayer.getFoodStats().getFoodLevel() > 6) {
                // تفعيل حالة الجري لمحاكي ضغط الزر
                net.minecraft.client.settings.KeyBinding.setKeyBindState(
                        mc.gameSettings.keyBindSprint.getKeyCode(), true
                );            }
        }
    }

    /**
     * دالة التعطيل (onDisable):
     * عندما يقوم اللاعب بإيقاف الموديول، نعيد زر الجري إلى وضعه الطبيعي.
     */
    @Override
    public void onDisable() {
        // إعادة فك الضغط عن زر الجري
        net.minecraft.client.settings.KeyBinding.setKeyBindState(
                mc.gameSettings.keyBindSprint.getKeyCode(), false
        );
    }}
