package com.customclient.module;

import com.customclient.CustomClient;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

/**
 * الكلاس الأساسي والمجرد لجميع الموديولات (Abstract Base Module Class).
 * 
 * في البرمجة كائنية التوجه (OOP)، يمثل هذا الكلاس مبدأ "التجريد والوراثة" (Inheritance).
 * كل ميزة أو موديول جديد نقوم ببنائه (مثل FPS أو ToggleSprint) سيرث هذا الكلاس
 * ويكتسب منه الخصائص الأساسية تلقائياً مثل التفعيل/التعطيل، الزر المخصص، والتصنيف.
 */
public abstract class Module {

    // المتغيرات الأساسية لكل موديول
    private final String name;           // اسم الموديول الفريد (مثال: "ToggleSprint")
    private final String description;    // وصف مختصر يوضح وظيفة الموديول للمستخدم
    private final Category category;     // التصنيف الذي ينتمي إليه (Movement, Render, HUD, إلخ)
    private int keyCode;                 // الزر المسؤول عن التبديل (من مكتبة LWJGL Keyboard)
    private boolean toggled;             // حالة الموديول الحالية: مفعل (true) أو معطل (false)

    // اختصار سريع للوصول لمحرك ماينكرافت لتسهيل العمل في الموديولات الفرعية
    protected final Minecraft mc = Minecraft.getMinecraft();

    /**
     * منشئ الموديول الأساسي (Constructor)
     * 
     * @param name اسم الموديول
     * @param description وصف الموديول
     * @param category تصنيف الموديول
     * @param keyCode الزر الافتراضي في لوحة المفاتيح (أو Keyboard.KEY_NONE إذا لم يكن له زر)
     */
    public Module(String name, String description, Category category, int keyCode) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.keyCode = keyCode;
        this.toggled = false; // افتراضياً تبدأ الموديولات معطلة ما لم نحدد غير ذلك
    }

    /**
     * دالة التبديل (Toggle):
     * تقوم بعكس حالة الموديول من مفعل إلى معطل والعكس،
     * واستدعاء الدوال التابعة، مع إرسال إشعار في الشات لتنبيه اللاعب.
     */
    public void toggle() {
        setToggled(!this.toggled);
    }

    /**
     * دالة تعيين الحالة يدوياً:
     * 
     * @param toggled الحالة الجديدة (true للتفعيل، false للتعطيل)
     */
    public void setToggled(boolean toggled) {
        if (this.toggled == toggled) {
            return; // لم تتغير الحالة، لا داعي لإعادة التنفيذ
        }

        this.toggled = toggled;

        if (this.toggled) {
            onEnable();
            sendToggleMessage(true);
        } else {
            onDisable();
            sendToggleMessage(false);
        }
    }

    /**
     * إرسال رسالة في الشات تنبه اللاعب بحالة الموديول
     */
    private void sendToggleMessage(boolean enabled) {
        if (mc.thePlayer != null) {
            String status = enabled 
                    ? EnumChatFormatting.GREEN + "مفعّل (Enabled)" 
                    : EnumChatFormatting.RED + "معطّل (Disabled)";
            
            mc.thePlayer.addChatMessage(new ChatComponentText(
                    CustomClient.CHAT_PREFIX + EnumChatFormatting.GRAY + "موديول " 
                    + EnumChatFormatting.WHITE + name + " " + status
            ));
        }
    }

    /**
     * دالة التفعيل (onEnable):
     * تُستدعى تلقائياً عندما يتحول الموديول إلى حالة العمل (Active).
     * يمكن للموديول الفرعي إعادة كتابتها (Override) لتسجيل مستمعي أحداث أو تفعيل تأثيرات معينة.
     */
    public void onEnable() {
        // يتم تطبيقها في الموديولات الفرعية عند الحاجة
    }

    /**
     * دالة التعطيل (onDisable):
     * تُستدعى تلقائياً عند إيقاف تشغيل الموديول.
     * تُستخدم لإعادة المؤثرات لطبيعتها (مثال: إعادة السطوع Gamma أو إيقاف الجري).
     */
    public void onDisable() {
        // يتم تطبيقها في الموديولات الفرعية عند الحاجة
    }

    /**
     * دالة التحديث في كل تكة (onTick / onUpdate):
     * تُستدعى 20 مرة في الثانية (كل Tick في اللعبة) طالما أن الموديول مفعل.
     * مناسبة للمنطق الحسابي والتحكم بحركة اللاعب.
     */
    public void onTick() {
        // يتم تطبيقها في الموديولات التي تحتاج لتحديث مستمر
    }

    /**
     * دالة الرسم على الشاشة ثنائية الأبعاد (onRender2D):
     * تُستدعى في كل إطار (Frame) طالما أن الموديول مفعل.
     * مناسبة لرسم عناصر الـ HUD مثل الـ FPS والنصوص والأشكال على الشاشة.
     */
    public void onRender2D() {
        // يتم تطبيقها في موديولات الـ HUD
    }

    // ==========================================
    // دوال القراءة والتعديل (Getters & Setters)
    // ==========================================

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public int getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(int keyCode) {
        this.keyCode = keyCode;
    }

    public boolean isToggled() {
        return toggled;
    }
}
