package com.customclient.module.render;

import com.customclient.module.Category;
import com.customclient.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * موديول الإضاءة الكاملة (Fullbright).
 * 
 * ميزة تعليمية وجمالية تتيح استكشاف الكهوف والمناطق المظلمة في طور Singleplayer
 * دون الحاجة لوضع شعلات مضيئة في كل مكان.
 * 
 * المفهوم البرمجي:
 * يوضح كيفية التعديل المباشر على إعدادات الرسوميات في ماينكرافت (GameSettings.gammaSetting)
 * وحفظ القيمة الأصلية للعودة إليها بأمان عند التعطيل.
 */
public class Fullbright extends Module {

    private float previousGamma = 1.0f; // للاحتفاظ بالقيمة السابقة لسطوع الشاشة

    public Fullbright() {
        super(
                "Fullbright", 
                "يرفع سطوع الشاشة إلى أقصى حد لرؤية واضحة في الكهوف والمناطق المظلمة", 
                Category.RENDER, 
                Keyboard.KEY_B
        );
    }

    /**
     * عند التفعيل: نحفظ السطوع القديم ثم نرفعه إلى 1000
     */
    @Override
    public void onEnable() {
        if (mc.gameSettings != null) {
            this.previousGamma = mc.gameSettings.gammaSetting;
            mc.gameSettings.gammaSetting = 1000f;
        }
    }

    /**
     * في كل تكة: نتأكد أن السطوع لم يُعد ضبطه بواسطة قائمة اللعبة
     */
    @Override
    public void onTick() {
        if (mc.gameSettings != null && mc.gameSettings.gammaSetting < 100f) {
            mc.gameSettings.gammaSetting = 1000f;
        }
    }

    /**
     * عند التعطيل: نعيد السطوع إلى قيمته الأصلية التي كان عليها قبل التفعيل
     */
    @Override
    public void onDisable() {
        if (mc.gameSettings != null) {
            mc.gameSettings.gammaSetting = this.previousGamma;
        }
    }
}
