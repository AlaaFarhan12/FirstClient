
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

public class WTap extends Module {

    private final ModeSetting mode = new ModeSetting(
            "Mode", "Legit", "Legit", "Blatant", "Manual"
    );

    private final NumberSetting delay =
            new NumberSetting("Delay", 100.0, 0.0, 300.0);

    private final BooleanSetting requireAttack =
            new BooleanSetting("Require Attack", true);

    private boolean previousAttackDown;
    private boolean sprintWasActive;
    private long attackStartTime;
    private long sprintRestoreTime;

    public WTap() {
        super("WTap", "Sprint timing training settings",
                Category.COMBAT, 0);

        addSetting(mode);
        addSetting(delay);
        addSetting(requireAttack);
    }

    @Override
    public void onEnable() {
        previousAttackDown = false;
        sprintWasActive = false;
        attackStartTime = 0L;
        sprintRestoreTime = 0L;
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null || mc.theWorld == null
                || mc.gameSettings == null || mc.currentScreen != null) {
            previousAttackDown = false;
            return;
        }

        if ("Manual".equalsIgnoreCase(mode.getValue())) {
            previousAttackDown =
                    mc.gameSettings.keyBindAttack.isKeyDown();
            return;
        }

        boolean attackDown =
                mc.gameSettings.keyBindAttack.isKeyDown();

        long now = System.currentTimeMillis();

        if (requireAttack.getValue() && !attackDown) {
            previousAttackDown = false;
            return;
        }

        if (attackDown && !previousAttackDown) {
            attackStartTime = now;
            sprintWasActive = mc.thePlayer.isSprinting();
        }

        if (attackDown && sprintWasActive && attackStartTime > 0L) {
            long elapsed = now - attackStartTime;
            long configuredDelay = (long) delay.getValue();

            if (elapsed >= configuredDelay) {
                if ("Blatant".equalsIgnoreCase(mode.getValue())) {
                    mc.thePlayer.setSprinting(true);
                } else if ("Legit".equalsIgnoreCase(mode.getValue())) {
                    // Observe timing without forcing sprint changes.
                    sprintRestoreTime = now;
                }

                attackStartTime = 0L;
                sprintWasActive = false;
            }
        }

        previousAttackDown = attackDown;
    }

    @Override
    public void onDisable() {
        previousAttackDown = false;
        sprintWasActive = false;
        attackStartTime = 0L;
        sprintRestoreTime = 0L;
    }

    public String getMode() {
        return mode.getValue();
    }

    public double getDelay() {
        return delay.getValue();
    }

    public boolean requiresAttack() {
        return requireAttack.getValue();
    }
}
