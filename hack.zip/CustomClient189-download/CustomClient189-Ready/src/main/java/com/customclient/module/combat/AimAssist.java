
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

public class AimAssist extends Module {

    private final ModeSetting mode = new ModeSetting(
            "Mode", "Legit", "Legit", "Blatant"
    );

    private final NumberSetting range =
            new NumberSetting("Range", 4.0, 1.0, 6.0);

    private final NumberSetting speed =
            new NumberSetting("Speed", 2.0, 1.0, 10.0);

    private final NumberSetting fov =
            new NumberSetting("FOV", 90.0, 30.0, 180.0);

    private final BooleanSetting playersOnly =
            new BooleanSetting("Players Only", true);

    private final BooleanSetting targetLock =
            new BooleanSetting("Target Lock", true);

    private final BooleanSetting horizontal =
            new BooleanSetting("Horizontal Aim", true);

    private final BooleanSetting vertical =
            new BooleanSetting("Vertical Aim", false);

    public AimAssist() {
        super("AimAssist", "Aim training configuration",
                Category.COMBAT, 0);

        addSetting(mode);
        addSetting(range);
        addSetting(speed);
        addSetting(fov);
        addSetting(playersOnly);
        addSetting(targetLock);
        addSetting(horizontal);
        addSetting(vertical);
    }

    public String getMode() {
        return mode.getValue();
    }

    public double getRange() {
        return range.getValue();
    }

    public double getSpeed() {
        return speed.getValue();
    }

    public double getFOV() {
        return fov.getValue();
    }

    public boolean isPlayersOnly() {
        return playersOnly.getValue();
    }

    public boolean isTargetLockEnabled() {
        return targetLock.getValue();
    }

    public boolean isHorizontalEnabled() {
        return horizontal.getValue();
    }

    public boolean isVerticalEnabled() {
        return vertical.getValue();
    }
}
