
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

import net.minecraft.entity.Entity;
import net.minecraft.util.MovingObjectPosition;

public class Reach extends Module {

    private final ModeSetting mode =
            new ModeSetting("Mode", "Legit", "Legit", "Blatant");

    private final NumberSetting distance =
            new NumberSetting("Distance", 3.2, 3.0, 6.0);

    private Entity currentTarget;
    private double currentDistance;

    public Reach() {
        super("Reach", "Configurable interaction distance",
                Category.COMBAT, 0);

        addSetting(mode);
        addSetting(distance);
    }

    @Override
    public void onEnable() {
        currentTarget = null;
        currentDistance = 0.0;
    }

    @Override
    public void onTick() {
        currentTarget = null;
        currentDistance = 0.0;

        if (mc.thePlayer == null
                || mc.theWorld == null
                || mc.currentScreen != null) {
            return;
        }

        MovingObjectPosition hit = mc.objectMouseOver;

        if (hit == null
                || hit.typeOfHit
                != MovingObjectPosition.MovingObjectType.ENTITY) {
            return;
        }

        Entity target = hit.entityHit;

        if (target == null || target == mc.thePlayer || target.isDead) {
            return;
        }

        double actualDistance =
                mc.thePlayer.getDistanceToEntity(target);

        double allowedDistance = distance.getValue();

        if ("Legit".equalsIgnoreCase(mode.getValue())) {
            allowedDistance = Math.min(allowedDistance, 3.0);
        }

        if (actualDistance <= allowedDistance) {
            currentTarget = target;
            currentDistance = actualDistance;
        }
    }

    @Override
    public void onDisable() {
        currentTarget = null;
        currentDistance = 0.0;
    }

    public String getMode() {
        return mode.getValue();
    }

    public double getDistance() {
        return distance.getValue();
    }

    public Entity getCurrentTarget() {
        return currentTarget;
    }

    public double getCurrentDistance() {
        return currentDistance;
    }

    public boolean isTargetWithinConfiguredDistance() {
        return currentTarget != null;
    }
}
