
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.util.MovingObjectPosition;

public class AutoBlock extends Module {

    private final ModeSetting mode =
            new ModeSetting("Mode", "Legit", "Legit", "Blatant");

    private final NumberSetting blockChance =
            new NumberSetting("Block Chance", 100.0, 0.0, 100.0);

    private final NumberSetting blockDelay =
            new NumberSetting("Block Delay", 100.0, 0.0, 500.0);

    private final NumberSetting blockDuration =
            new NumberSetting("Block Duration", 200.0, 50.0, 1000.0);

    private final BooleanSetting requireSword =
            new BooleanSetting("Require Sword", true);

    private final BooleanSetting requirePress =
            new BooleanSetting("Require Press", true);

    private final BooleanSetting stopOnGUI =
            new BooleanSetting("Stop on GUI", true);

    private long lastActionTime;
    private boolean blocking;
    private boolean modulePressedUse;
    private boolean previousUseKeyState;

    public AutoBlock() {
        super(
                "AutoBlock",
                "Blocks while targeting a player with a sword",
                Category.COMBAT,
                0
        );

        addSetting(mode);
        addSetting(blockChance);
        addSetting(blockDelay);
        addSetting(blockDuration);
        addSetting(requireSword);
        addSetting(requirePress);
        addSetting(stopOnGUI);
    }

    @Override
    public void onEnable() {
        lastActionTime = System.currentTimeMillis();
        blocking = false;
        modulePressedUse = false;
        previousUseKeyState = false;
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null
                || mc.theWorld == null
                || mc.gameSettings == null) {
            stopBlocking();
            return;
        }

        if (stopOnGUI.getValue() && mc.currentScreen != null) {
            stopBlocking();
            return;
        }

        if (requireSword.getValue()) {
            if (mc.thePlayer.getHeldItem() == null
                    || !(mc.thePlayer.getHeldItem().getItem()
                    instanceof ItemSword)) {
                stopBlocking();
                return;
            }
        }

        boolean attacking =
                mc.gameSettings.keyBindAttack.isKeyDown();

        if (requirePress.getValue() && !attacking) {
            stopBlocking();
            return;
        }

        MovingObjectPosition hit = mc.objectMouseOver;

        boolean targetingPlayer =
                hit != null
                        && hit.typeOfHit
                        == MovingObjectPosition.MovingObjectType.ENTITY
                        && hit.entityHit instanceof EntityPlayer
                        && hit.entityHit != mc.thePlayer;

        if (!targetingPlayer) {
            stopBlocking();
            return;
        }

        long now = System.currentTimeMillis();

        if (blocking) {
            if (now - lastActionTime >= blockDuration.getValue()) {
                stopBlocking();
                lastActionTime = now;
            }
            return;
        }

        if (now - lastActionTime < blockDelay.getValue()) {
            return;
        }

        if (Math.random() * 100.0 >= blockChance.getValue()) {
            lastActionTime = now;
            return;
        }

        startBlocking();
        lastActionTime = now;
    }

    private void startBlocking() {
        if (mc.gameSettings == null || modulePressedUse) {
            return;
        }

        int keyCode = mc.gameSettings.keyBindUseItem.getKeyCode();

        // Do not override an already-held use key.
        if (mc.gameSettings.keyBindUseItem.isKeyDown()) {
            return;
        }

        previousUseKeyState =
                mc.gameSettings.keyBindUseItem.isKeyDown();

        KeyBinding.setKeyBindState(keyCode, true);

        modulePressedUse = true;
        blocking = true;
    }

    private void stopBlocking() {
        if (modulePressedUse && mc.gameSettings != null) {
            int keyCode = mc.gameSettings.keyBindUseItem.getKeyCode();

            KeyBinding.setKeyBindState(
                    keyCode,
                    previousUseKeyState
            );
        }

        modulePressedUse = false;
        blocking = false;
    }

    @Override
    public void onDisable() {
        stopBlocking();
    }

    public String getMode() {
        return mode.getValue();
    }

    public double getBlockChance() {
        return blockChance.getValue();
    }

    public double getBlockDelay() {
        return blockDelay.getValue();
    }

    public double getBlockDuration() {
        return blockDuration.getValue();
    }

    public boolean requiresSword() {
        return requireSword.getValue();
    }

    public boolean isRequirePressEnabled() {
        return requirePress.getValue();
    }

    public boolean isStopOnGUIEnabled() {
        return stopOnGUI.getValue();
    }
}
