
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

public class NoHitDelay extends Module {

    private final ModeSetting mode = new ModeSetting(
            "Mode",
            "Practice",
            "Practice",
            "Display"
    );

    private final NumberSetting delay = new NumberSetting(
            "Delay",
            500.0,
            0.0,
            1000.0
    );

    private long lastAttackTime;
    private long lastInterval;
    private int recordedAttacks;

    public NoHitDelay() {
        super(
                "NoHitDelay",
                "Hit delay practice settings",
                Category.COMBAT,
                0
        );

        addSetting(mode);
        addSetting(delay);
    }

    @Override
    public void onEnable() {
        lastAttackTime = 0L;
        lastInterval = 0L;
        recordedAttacks = 0;
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null
                || mc.theWorld == null
                || mc.currentScreen != null) {
            return;
        }

        if (isDisplayMode()) {
            return;
        }

        // Practice mode records timing when the attack key is pressed.
        if (mc.gameSettings.keyBindAttack.isPressed()) {
            long now = System.currentTimeMillis();

            if (lastAttackTime > 0L) {
                lastInterval = now - lastAttackTime;
            }

            lastAttackTime = now;
            recordedAttacks++;
        }
    }

    @Override
    public void onDisable() {
        lastAttackTime = 0L;
        lastInterval = 0L;
        recordedAttacks = 0;
    }

    public String getMode() {
        return mode.getValue();
    }

    public double getDelay() {
        return delay.getValue();
    }

    public boolean isPracticeMode() {
        return "Practice".equalsIgnoreCase(mode.getValue());
    }

    public boolean isDisplayMode() {
        return "Display".equalsIgnoreCase(mode.getValue());
    }

    public long getLastInterval() {
        return lastInterval;
    }

    public int getRecordedAttacks() {
        return recordedAttacks;
    }

    public boolean isDelayReady() {
        return lastAttackTime == 0L
                || System.currentTimeMillis() - lastAttackTime
                >= (long) delay.getValue();
    }
}
