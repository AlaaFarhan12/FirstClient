
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.NumberSetting;

import net.minecraft.client.gui.GuiScreen;

import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

public class AutoUse extends Module {

    private final BooleanSetting[] slots = new BooleanSetting[9];

    private final NumberSetting returnSlot =
            new NumberSetting("Return Slot", 1.0, 1.0, 9.0);

    private int selectedIndex = -1;
    private int previousSlot = 0;

    private boolean cycleKeyWasDown;
    private boolean returnKeyWasDown;

    public AutoUse() {
        super(
                "AutoUse",
                "Quickly switch between selected hotbar slots",
                Category.COMBAT,
                0
        );

        for (int i = 0; i < 9; i++) {
            slots[i] = new BooleanSetting("Hotbar " + (i + 1), i == 4);
            addSetting(slots[i]);
        }

        addSetting(returnSlot);
    }

    @Override
    public void onEnable() {
        selectedIndex = -1;
        cycleKeyWasDown = false;
        returnKeyWasDown = false;
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null
                || mc.theWorld == null
                || mc.currentScreen != null) {
            cycleKeyWasDown = false;
            returnKeyWasDown = false;
            return;
        }

        boolean cycleDown = Keyboard.isKeyDown(Keyboard.KEY_V);
        boolean returnDown = Keyboard.isKeyDown(Keyboard.KEY_B);

        // V: switch immediately to the next selected hotbar slot.
        if (cycleDown && !cycleKeyWasDown) {
            switchToNextSelectedSlot();
        }

        // B: return immediately to the configured slot.
        if (returnDown && !returnKeyWasDown) {
            mc.thePlayer.inventory.currentItem =
                    clampSlot((int) returnSlot.getValue());
            selectedIndex = -1;
        }

        cycleKeyWasDown = cycleDown;
        returnKeyWasDown = returnDown;
    }

    private void switchToNextSelectedSlot() {
        List<Integer> selectedSlots = new ArrayList<Integer>();

        for (int i = 0; i < slots.length; i++) {
            if (slots[i].getValue()) {
                selectedSlots.add(i);
            }
        }

        if (selectedSlots.isEmpty()) {
            return;
        }

        int current = mc.thePlayer.inventory.currentItem;
        int nextPosition = 0;

        if (selectedIndex >= 0) {
            nextPosition = (selectedIndex + 1) % selectedSlots.size();
        } else {
            int found = selectedSlots.indexOf(current);
            nextPosition = (found + 1) % selectedSlots.size();
        }

        selectedIndex = nextPosition;

        mc.thePlayer.inventory.currentItem =
                selectedSlots.get(nextPosition);
    }

    private int clampSlot(int slot) {
        return Math.max(0, Math.min(8, slot - 1));
    }

    @Override
    public void onDisable() {
        selectedIndex = -1;
        cycleKeyWasDown = false;
        returnKeyWasDown = false;
    }

    public BooleanSetting[] getSlotSettings() {
        return slots;
    }

    public int getReturnSlot() {
        return (int) returnSlot.getValue();
    }
}
