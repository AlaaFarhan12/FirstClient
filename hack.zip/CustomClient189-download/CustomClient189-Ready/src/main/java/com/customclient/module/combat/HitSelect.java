
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MovingObjectPosition;

public class HitSelect extends Module {

    private final ModeSetting mode = new ModeSetting(
            "Mode", "Legit", "Legit", "Blatant", "Custom"
    );

    private final NumberSetting delay =
            new NumberSetting("Delay", 100.0, 0.0, 500.0);

    private final BooleanSetting requireTarget =
            new BooleanSetting("Require Target", true);

    private final BooleanSetting playersOnly =
            new BooleanSetting("Players Only", true);

    private final BooleanSetting requireGround =
            new BooleanSetting("Require Ground", true);

    private long lastAttackTime;
    private boolean previousAttackDown;

    public HitSelect() {
        super("HitSelect", "Attack timing training settings",
                Category.COMBAT, 0);

        addSetting(mode);
        addSetting(delay);
        addSetting(requireTarget);
        addSetting(playersOnly);
        addSetting(requireGround);
    }

    @Override
    public void onEnable() {
        lastAttackTime = 0L;
        previousAttackDown = false;
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null
                || mc.theWorld == null
                || mc.currentScreen != null) {
            previousAttackDown = false;
            return;
        }

        boolean attackDown =
                mc.gameSettings.keyBindAttack.isKeyDown();

        if (!attackDown) {
            previousAttackDown = false;
            return;
        }

        if (previousAttackDown) {
            return;
        }

        previousAttackDown = true;

        if (requireGround.getValue() && !mc.thePlayer.onGround) {
            return;
        }

        if (requireTarget.getValue() && !hasValidTarget()) {
            return;
        }

        long now = System.currentTimeMillis();
        long configuredDelay = (long) delay.getValue();

        if ("Legit".equalsIgnoreCase(mode.getValue())) {
            // Observe attack timing without changing the attack input.
            lastAttackTime = now;
        } else if ("Blatant".equalsIgnoreCase(mode.getValue())) {
            // Record the attack event immediately.
            lastAttackTime = now;
        } else if ("Custom".equalsIgnoreCase(mode.getValue())) {
            if (lastAttackTime == 0L
                    || now - lastAttackTime >= configuredDelay) {
                lastAttackTime = now;
            }
        }
    }

    private boolean hasValidTarget() {
        MovingObjectPosition hit = mc.objectMouseOver;

        if (hit == null
                || hit.typeOfHit
                != MovingObjectPosition.MovingObjectType.ENTITY) {
            return false;
        }

        Entity target = hit.entityHit;

        if (target == null || target == mc.thePlayer || target.isDead) {
            return false;
        }

        if (playersOnly.getValue()
                && !(target instanceof EntityPlayer)) {
            return false;
        }

        if (target instanceof EntityPlayer
                && ((EntityPlayer) target).getHealth() <= 0.0F) {
            return false;
        }

        return true;
    }

    @Override
    public void onDisable() {
        previousAttackDown = false;
        lastAttackTime = 0L;
    }

    public String getMode() {
        return mode.getValue();
    }

    public double getDelay() {
        return delay.getValue();
    }

    public boolean requiresTarget() {
        return requireTarget.getValue();
    }

    public boolean isPlayersOnly() {
        return playersOnly.getValue();
    }

    public boolean requiresGround() {
        return requireGround.getValue();
    }
}
