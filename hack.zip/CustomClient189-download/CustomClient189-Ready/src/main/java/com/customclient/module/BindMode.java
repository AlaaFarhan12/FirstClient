package com.customclient.module;

public enum BindMode {
    TOGGLE,
    HOLD
}