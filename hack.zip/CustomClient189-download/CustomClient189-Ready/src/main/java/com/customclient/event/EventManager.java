
package com.customclient.event;

import java.util.ArrayList;
import java.util.List;

public class EventManager {

    private final List<EventListener> listeners =
            new ArrayList<EventListener>();

    public void register(EventListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void unregister(EventListener listener) {
        listeners.remove(listener);
    }

    public void post(UpdateEvent event) {
        for (EventListener listener :
                new ArrayList<EventListener>(listeners)) {
            listener.onUpdate(event);
        }
    }

    public void post(Render2DEvent event) {
        for (EventListener listener :
                new ArrayList<EventListener>(listeners)) {
            listener.onRender2D(event);
        }
    }
}
