
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

import net.minecraft.util.MathHelper;

public class Criticals extends Module {

    private final ModeSetting mode = new ModeSetting(
            "Mode",
            "Practice",
            "Practice",
            "Jump",
            "Timed",
            "Manual"
    );

    private final NumberSetting jumpHeight =
            new NumberSetting("Jump Height", 0.10, 0.05, 0.42);

    private final NumberSetting cooldown =
            new NumberSetting("Cooldown MS", 500.0, 100.0, 2000.0);

    private final BooleanSetting requireGround =
            new BooleanSetting("Require Ground", true);

    private final BooleanSetting requireAttack =
            new BooleanSetting("Require Attack", true);

    private long lastActionTime;
    private boolean wasAttackDown;

    public Criticals() {
        super(
                "Criticals",
                "Local critical-hit practice modes",
                Category.COMBAT,
                0
        );

        addSetting(mode);
        addSetting(jumpHeight);
        addSetting(cooldown);
        addSetting(requireGround);
        addSetting(requireAttack);
    }

    @Override
    public void onEnable() {
        lastActionTime = 0L;
        wasAttackDown = false;
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null
                || mc.theWorld == null
                || mc.currentScreen != null) {
            wasAttackDown = false;
            return;
        }

        boolean attackDown =
                mc.gameSettings.keyBindAttack.isKeyDown();

        if ("Manual".equalsIgnoreCase(mode.getValue())) {
            wasAttackDown = attackDown;
            return;
        }

        if (requireAttack.getValue() && !attackDown) {
            wasAttackDown = false;
            return;
        }

        if (requireGround.getValue() && !mc.thePlayer.onGround) {
            wasAttackDown = attackDown;
            return;
        }

        long now = System.currentTimeMillis();

        if (now - lastActionTime < (long) cooldown.getValue()) {
            wasAttackDown = attackDown;
            return;
        }

        if ("Jump".equalsIgnoreCase(mode.getValue())) {
            if (attackDown && !wasAttackDown && mc.thePlayer.onGround) {
                mc.thePlayer.jump();
                lastActionTime = now;
            }
        } else if ("Timed".equalsIgnoreCase(mode.getValue())) {
            if (attackDown && mc.thePlayer.onGround) {
                mc.thePlayer.jump();
                lastActionTime = now;
            }
        } else if ("Practice".equalsIgnoreCase(mode.getValue())) {
            // Practice mode only reacts to a new attack press.
            if (attackDown && !wasAttackDown) {
                lastActionTime = now;
            }
        }

        wasAttackDown = attackDown;
    }

    @Override
    public void onDisable() {
        wasAttackDown = false;
    }

    public String getMode() {
        return mode.getValue();
    }

    public double getJumpHeight() {
        return jumpHeight.getValue();
    }

    public double getCooldown() {
        return cooldown.getValue();
    }

    public boolean isRequireGround() {
        return requireGround.getValue();
    }

    public boolean isRequireAttack() {
        return requireAttack.getValue();
    }
}
