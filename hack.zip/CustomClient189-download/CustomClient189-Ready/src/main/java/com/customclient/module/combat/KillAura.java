
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class KillAura extends Module {

    private final ModeSetting mode = new ModeSetting(
            "Mode", "Legit", "Legit", "Blatant"
    );

    private final ModeSetting targetType = new ModeSetting(
            "Target Type", "Players", "Players", "Mobs", "Both"
    );

    private final ModeSetting targetMode = new ModeSetting(
            "Target Mode", "Distance",
            "Distance", "Health", "Crosshair"
    );

    private final ModeSetting sortMode = new ModeSetting(
            "Sort Mode", "Closest",
            "Closest", "Lowest Health", "Angle"
    );

    private final NumberSetting range =
            new NumberSetting("Range", 3.5, 1.0, 6.0);

    private final NumberSetting rotationSpeed =
            new NumberSetting("Rotation Speed", 5.0, 1.0, 10.0);

    private final NumberSetting attackDelay =
            new NumberSetting("Attack Delay", 250.0, 50.0, 1000.0);

    private final BooleanSetting targetLock =
            new BooleanSetting("Target Lock", true);

    private final BooleanSetting throughWalls =
            new BooleanSetting("Through Walls", false);

    private final BooleanSetting ignoreInvisible =
            new BooleanSetting("Ignore Invisible", true);

    private final BooleanSetting ignoreTeammates =
            new BooleanSetting("Ignore Teammates", false);

    private final BooleanSetting requireLineOfSight =
            new BooleanSetting("Line Of Sight", true);

    private EntityLivingBase currentTarget;
    private final List<EntityLivingBase> targets =
            new ArrayList<EntityLivingBase>();

    private long lastTargetUpdate;
    private long lastAttackTime;

    public KillAura() {
        super(
                "KillAura",
                "Combat target selection and practice",
                Category.COMBAT,
                0
        );

        addSetting(mode);
        addSetting(targetType);
        addSetting(targetMode);
        addSetting(sortMode);
        addSetting(range);
        addSetting(rotationSpeed);
        addSetting(attackDelay);
        addSetting(targetLock);
        addSetting(throughWalls);
        addSetting(ignoreInvisible);
        addSetting(ignoreTeammates);
        addSetting(requireLineOfSight);
    }

    @Override
    public void onEnable() {
        currentTarget = null;
        targets.clear();
        lastTargetUpdate = 0L;
        lastAttackTime = 0L;
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null
                || mc.theWorld == null
                || mc.currentScreen != null) {
            clearTargets();
            return;
        }

        long now = System.currentTimeMillis();

        // Refresh target selection at most once per 50 ms.
        if (now - lastTargetUpdate < 50L) {
            if (!isValidTarget(currentTarget)) {
                currentTarget = null;
            }
            return;
        }

        lastTargetUpdate = now;
        updateTargets();

        if (targetLock.getValue() && isValidTarget(currentTarget)) {
            return;
        }

        currentTarget = selectTarget();
    }

    private void updateTargets() {
        targets.clear();

        for (Object object : mc.theWorld.loadedEntityList) {
            if (!(object instanceof EntityLivingBase)) {
                continue;
            }

            EntityLivingBase entity = (EntityLivingBase) object;

            if (isValidTarget(entity)) {
                targets.add(entity);
            }
        }

        sortTargets();
    }

    private boolean isValidTarget(EntityLivingBase entity) {
        if (entity == null
                || entity == mc.thePlayer
                || entity.isDead
                || entity.getHealth() <= 0.0F) {
            return false;
        }

        if (mc.thePlayer.getDistanceToEntity(entity) > range.getValue()) {
            return false;
        }

        if (entity.isInvisible() && ignoreInvisible.getValue()) {
            return false;
        }

        if (!isAllowedType(entity)) {
            return false;
        }

        if (entity instanceof EntityPlayer && ignoreTeammates.getValue()) {
            EntityPlayer player = (EntityPlayer) entity;

            if (mc.thePlayer.isOnSameTeam(player)) {
                return false;
            }
        }

        if (!throughWalls.getValue()
                && requireLineOfSight.getValue()
                && !mc.thePlayer.canEntityBeSeen(entity)) {
            return false;
        }

        if ("Crosshair".equalsIgnoreCase(targetMode.getValue())) {
            MovingObjectPosition hit = mc.objectMouseOver;

            return hit != null
                    && hit.typeOfHit
                    == MovingObjectPosition.MovingObjectType.ENTITY
                    && hit.entityHit == entity;
        }

        return true;
    }

    private boolean isAllowedType(EntityLivingBase entity) {
        String type = targetType.getValue();

        if (entity instanceof EntityPlayer) {
            return "Players".equalsIgnoreCase(type)
                    || "Both".equalsIgnoreCase(type);
        }

        if (entity instanceof EntityMob || entity instanceof EntityAnimal) {
            return "Mobs".equalsIgnoreCase(type)
                    || "Both".equalsIgnoreCase(type);
        }

        return false;
    }

    private void sortTargets() {
        final String sort = sortMode.getValue();

        Collections.sort(targets, new Comparator<EntityLivingBase>() {
            @Override
            public int compare(EntityLivingBase first,
                               EntityLivingBase second) {

                if ("Lowest Health".equalsIgnoreCase(sort)) {
                    return Float.compare(
                            first.getHealth(), second.getHealth());
                }

                if ("Angle".equalsIgnoreCase(sort)) {
                    return Float.compare(
                            getYawDifference(first),
                            getYawDifference(second));
                }

                return Double.compare(
                        mc.thePlayer.getDistanceToEntity(first),
                        mc.thePlayer.getDistanceToEntity(second));
            }
        });
    }

    private EntityLivingBase selectTarget() {
        if (targets.isEmpty()) {
            return null;
        }

        if ("Health".equalsIgnoreCase(targetMode.getValue())) {
            EntityLivingBase lowest = null;

            for (EntityLivingBase entity : targets) {
                if (lowest == null
                        || entity.getHealth() < lowest.getHealth()) {
                    lowest = entity;
                }
            }

            return lowest;
        }

        if ("Crosshair".equalsIgnoreCase(targetMode.getValue())) {
            for (EntityLivingBase entity : targets) {
                if (isUnderCrosshair(entity)) {
                    return entity;
                }
            }

            return null;
        }

        return targets.get(0);
    }

    private boolean isUnderCrosshair(Entity entity) {
        MovingObjectPosition hit = mc.objectMouseOver;

        return hit != null
                && hit.typeOfHit
                == MovingObjectPosition.MovingObjectType.ENTITY
                && hit.entityHit == entity;
    }

    private float getYawDifference(Entity entity) {
        double dx = entity.posX - mc.thePlayer.posX;
        double dz = entity.posZ - mc.thePlayer.posZ;

        float targetYaw = (float) (
                Math.atan2(dz, dx) * 180.0 / Math.PI
        ) - 90.0F;

        return Math.abs(MathHelper.wrapAngleTo180_float(
                targetYaw - mc.thePlayer.rotationYaw));
    }

    private void clearTargets() {
        targets.clear();
        currentTarget = null;
    }

    @Override
    public void onDisable() {
        clearTargets();
        lastTargetUpdate = 0L;
        lastAttackTime = 0L;
    }

    public EntityLivingBase getCurrentTarget() {
        return currentTarget;
    }

    public List<EntityLivingBase> getTargets() {
        return Collections.unmodifiableList(targets);
    }

    public int getTargetCount() {
        return targets.size();
    }

    public String getMode() {
        return mode.getValue();
    }

    public String getTargetType() {
        return targetType.getValue();
    }

    public String getTargetMode() {
        return targetMode.getValue();
    }

    public String getSortMode() {
        return sortMode.getValue();
    }

    public double getRange() {
        return range.getValue();
    }

    public double getRotationSpeed() {
        return rotationSpeed.getValue();
    }

    public double getAttackDelay() {
        return attackDelay.getValue();
    }

    public boolean isTargetLockEnabled() {
        return targetLock.getValue();
    }

    public boolean canAttackThroughWalls() {
        return throughWalls.getValue();
    }

    public boolean isIgnoreInvisibleEnabled() {
        return ignoreInvisible.getValue();
    }

    public boolean isIgnoreTeammatesEnabled() {
        return ignoreTeammates.getValue();
    }

    public boolean requiresLineOfSight() {
        return requireLineOfSight.getValue();
    }

    public long getLastAttackTime() {
        return lastAttackTime;
    }
}
