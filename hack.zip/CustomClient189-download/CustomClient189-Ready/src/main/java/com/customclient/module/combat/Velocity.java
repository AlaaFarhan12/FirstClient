
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

public class Velocity extends Module {

    private final ModeSetting mode = new ModeSetting(
            "Mode",
            "Legit",
            "Legit",
            "Blatant",
            "Custom",
            "Horizontal",
            "Vertical",
            "Balanced"
    );

    private final NumberSetting horizontal =
            new NumberSetting("Horizontal", 100.0, 0.0, 100.0);

    private final NumberSetting vertical =
            new NumberSetting("Vertical", 100.0, 0.0, 100.0);

    private final NumberSetting delay =
            new NumberSetting("Delay", 0.0, 0.0, 500.0);

    private long lastUpdateTime;

    public Velocity() {
        super("Velocity", "Knockback configuration and inspection",
                Category.COMBAT, 0);

        addSetting(mode);
        addSetting(horizontal);
        addSetting(vertical);
        addSetting(delay);
    }

    @Override
    public void onEnable() {
        lastUpdateTime = 0L;
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null || mc.theWorld == null
                || mc.currentScreen != null) {
            lastUpdateTime = 0L;
            return;
        }

        long now = System.currentTimeMillis();
        long configuredDelay = (long) delay.getValue();

        if (lastUpdateTime == 0L
                || now - lastUpdateTime >= configuredDelay) {
            lastUpdateTime = now;
        }
    }

    @Override
    public void onDisable() {
        lastUpdateTime = 0L;
    }

    public String getMode() {
        return mode.getValue();
    }

    public double getHorizontal() {
        return horizontal.getValue();
    }

    public double getVertical() {
        return vertical.getValue();
    }

    public double getDelay() {
        return delay.getValue();
    }

    public double getEffectiveHorizontal() {
        switch (mode.getValue()) {
            case "Horizontal":
                return horizontal.getValue();
            case "Vertical":
                return 100.0;
            case "Balanced":
                return 75.0;
            case "Blatant":
                return 0.0;
            case "Custom":
                return horizontal.getValue();
            default:
                return 100.0;
        }
    }

    public double getEffectiveVertical() {
        switch (mode.getValue()) {
            case "Horizontal":
                return 100.0;
            case "Vertical":
                return vertical.getValue();
            case "Balanced":
                return 75.0;
            case "Blatant":
                return 0.0;
            case "Custom":
                return vertical.getValue();
            default:
                return 100.0;
        }
    }

    public long getLastUpdateTime() {
        return lastUpdateTime;
    }
}
