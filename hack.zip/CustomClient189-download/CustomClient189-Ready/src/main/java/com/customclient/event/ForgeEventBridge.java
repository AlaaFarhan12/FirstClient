
package com.customclient.event;

import com.customclient.CustomClient;
import com.customclient.module.Module;

import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.List;

public class ForgeEventBridge {

    private final EventManager eventManager = new EventManager();

    private final List<EventListener> registeredListeners =
            new ArrayList<EventListener>();

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }

        syncListeners();
        eventManager.post(new UpdateEvent());
    }

    @SubscribeEvent
    public void onRender2D(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) {
            return;
        }

        eventManager.post(new Render2DEvent(
                event.partialTicks,
                event.resolution.getScaledWidth(),
                event.resolution.getScaledHeight()
        ));
    }

    private void syncListeners() {
        if (CustomClient.getInstance() == null
                || CustomClient.getInstance().getModuleManager() == null) {
            return;
        }

        List<Module> modules =
                CustomClient.getInstance().getModuleManager().getModules();

        for (Module module : modules) {
            if (!(module instanceof EventListener)) {
                continue;
            }

            EventListener listener = (EventListener) module;

            if (module.isToggled()) {
                if (!registeredListeners.contains(listener)) {
                    eventManager.register(listener);
                    registeredListeners.add(listener);
                }
            } else {
                eventManager.unregister(listener);
                registeredListeners.remove(listener);
            }
        }

        List<EventListener> activeListeners =
                new ArrayList<EventListener>(registeredListeners);

        for (EventListener listener : activeListeners) {
            boolean found = false;

            for (Module module : modules) {
                if (module == listener && module.isToggled()) {
                    found = true;
                    break;
                }
            }

            if (!found) {
                eventManager.unregister(listener);
                registeredListeners.remove(listener);
            }
        }
    }
}
