
package com.customclient.event;

public interface EventListener {

    default void onUpdate(UpdateEvent event) {
    }

    default void onRender2D(Render2DEvent event) {
    }
}
