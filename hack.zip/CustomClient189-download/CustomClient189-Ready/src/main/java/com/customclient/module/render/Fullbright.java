
package com.customclient.module.render;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.NumberSetting;

public class Fullbright extends Module {

    private float oldGamma;

    private final NumberSetting brightness =
            new NumberSetting("Brightness", 1.0, 0.1, 5.0);

    public Fullbright() {
        super(
                "Fullbright",
                "Adjusts game brightness",
                Category.RENDER,
                0
        );

        addSetting(brightness);
    }

    @Override
    public void onEnable() {
        if (mc.gameSettings != null) {
            oldGamma = mc.gameSettings.gammaSetting;
        }
    }

    @Override
    public void onTick() {
        if (mc.gameSettings == null) {
            return;
        }

        mc.gameSettings.gammaSetting =
                (float) brightness.getValue();
    }

    @Override
    public void onDisable() {
        if (mc.gameSettings != null) {
            mc.gameSettings.gammaSetting = oldGamma;
        }
    }
}
