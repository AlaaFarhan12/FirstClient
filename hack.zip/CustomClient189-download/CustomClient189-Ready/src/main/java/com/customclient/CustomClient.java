
package com.customclient;

import com.customclient.gui.ClickGUI;
import com.customclient.module.ModuleManager;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import org.lwjgl.input.Keyboard;

@Mod(
        modid = CustomClient.MODID,
        name = CustomClient.NAME,
        version = CustomClient.VERSION
)
public class CustomClient {

    public static final String CHAT_PREFIX = "[CustomClient] ";
    public static final String MODID = "customclient";
    public static final String NAME = "Vampire Client";
    public static final String VERSION = "1.0.0";


    @Mod.Instance(MODID)
    private static CustomClient instance;

    private ModuleManager moduleManager;

    public static CustomClient getInstance() {
        return instance;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        instance = this;
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        moduleManager = new ModuleManager();

        ConfigManager.load(moduleManager);

        MinecraftForge.EVENT_BUS.register(this);
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        // Reserved for future initialization.
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }

        if (moduleManager == null) {
            return;
        }

        moduleManager.onTick();
    }

    @SubscribeEvent
    public void onRenderTick(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) {
            return;
        }

        if (moduleManager == null) {
            return;
        }

        moduleManager.onRender2D();
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (!Keyboard.getEventKeyState()) {
            return;
        }

        int key = Keyboard.getEventKey();

        if (key <= 0) {
            return;
        }

        Minecraft mc = Minecraft.getMinecraft();

        if (key == Keyboard.KEY_RSHIFT) {
            if (mc.currentScreen == null) {
                mc.displayGuiScreen(new ClickGUI());
            } else if (mc.currentScreen instanceof ClickGUI) {
                mc.displayGuiScreen(null);
            }
            return;
        }

        if (mc.currentScreen != null || moduleManager == null) {
            return;
        }

        moduleManager.onKeyPressed(key);
    }
}
