
package com.customclient.module;

public enum Category {

    MOVEMENT("حركة", "Movement"),
    RENDER("رسوميات", "Render"),
    HUD("الواجهة", "HUD"),
    PLAYER("اللاعب", "Player"),
    COMBAT("قتال", "Combat");

    private final String displayNameArabic;
    private final String displayNameEnglish;

    Category(String displayNameArabic, String displayNameEnglish) {
        this.displayNameArabic = displayNameArabic;
        this.displayNameEnglish = displayNameEnglish;
    }

    public String getDisplayNameArabic() {
        return displayNameArabic;
    }

    public String getDisplayNameEnglish() {
        return displayNameEnglish;
    }
}
