
package com.customclient.gui;

import com.customclient.CustomClient;
import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.Setting;
import com.customclient.setting.NumberSetting;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.BooleanSetting;

import net.minecraft.client.gui.GuiScreen;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.List;

public class ClickGUI extends GuiScreen {

    private static final int BG = 0xEE10101B;
    private static final int PANEL = 0xFF191927;
    private static final int LIGHT = 0xFF242438;
    private static final int PURPLE = 0xFF9B5CFF;
    private static final int DARK_PURPLE = 0xFF6938B8;
    private static final int WHITE = 0xFFF2F0FA;
    private static final int GRAY = 0xFFAAA7BC;
    private static final int GREEN = 0xFF73E6B0;
    private static final int RED = 0xFFFF7070;

    private static final int GUI_WIDTH = 540;
    private static final int GUI_HEIGHT = 320;

    private int guiX;
    private int guiY;

    private int selectedCategory;
    private Module selectedModule;

    private int moduleScroll;
    private int settingScroll;

    private boolean dragging;
    private int dragOffsetX;
    private int dragOffsetY;

    private boolean draggingSlider;
    private NumberSetting activeSlider;

    private Module bindingModule;
    private final Category[] categories = Category.values();

    @Override
    public void initGui() {
        super.initGui();

        guiX = (width - GUI_WIDTH) / 2;
        guiY = (height - GUI_HEIGHT) / 2;

        dragging = false;
        draggingSlider = false;
        activeSlider = null;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();

        guiX = Math.max(0, Math.min(guiX, width - GUI_WIDTH));
        guiY = Math.max(0, Math.min(guiY, height - GUI_HEIGHT));

        drawRect(guiX, guiY, guiX + GUI_WIDTH,
                guiY + GUI_HEIGHT, BG);

        drawRect(guiX, guiY, guiX + GUI_WIDTH,
                guiY + 38, PANEL);

        drawRect(guiX, guiY + 37, guiX + GUI_WIDTH,
                guiY + 39, PURPLE);

        fontRendererObj.drawString("VAMPIRE", guiX + 14,
                guiY + 13, WHITE);
        fontRendererObj.drawString("CLIENT", guiX + 75,
                guiY + 13, PURPLE);

        fontRendererObj.drawString("1.8.9",
                guiX + GUI_WIDTH - 48, guiY + 14, GRAY);

        int contentY = guiY + 39;
        int bottom = guiY + GUI_HEIGHT;

        drawRect(guiX, contentY, guiX + 112, bottom, PANEL);
        drawRect(guiX + 112, contentY,
                guiX + 300, bottom, BG);
        drawRect(guiX + 300, contentY,
                guiX + GUI_WIDTH, bottom, PANEL);

        fontRendererObj.drawString("CATEGORIES",
                guiX + 10, contentY + 12, PURPLE);
        fontRendererObj.drawString("MODULES",
                guiX + 122, contentY + 12, PURPLE);
        fontRendererObj.drawString("SETTINGS",
                guiX + 310, contentY + 12, PURPLE);

        drawCategories(contentY, bottom, mouseX, mouseY);
        drawModules(contentY, bottom, mouseX, mouseY);
        drawSettings(contentY, bottom);

        drawRect(guiX, bottom - 18,
                guiX + GUI_WIDTH, bottom, PANEL);

        fontRendererObj.drawString(
                bindingModule == null
                        ? "RSHIFT | CLOSE"
                        : "PRESS A KEY | ESC CANCEL | BACKSPACE CLEAR",
                guiX + 10, bottom - 12,
                bindingModule == null ? GRAY : PURPLE);

        fontRendererObj.drawString("VAMPIRE CLIENT",
                guiX + GUI_WIDTH - 100, bottom - 12, PURPLE);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void drawCategories(int contentY, int bottom,
                                int mouseX, int mouseY) {
        int startY = contentY + 31;

        for (int i = 0; i < categories.length; i++) {
            int y = startY + i * 29;

            if (y + 29 > bottom - 22) {
                break;
            }

            boolean selected = i == selectedCategory;
            boolean hovered = inside(mouseX, mouseY,
                    guiX, y, 112, 29);

            if (selected || hovered) {
                drawRect(guiX + 5, y + 2,
                        guiX + 107, y + 27,
                        selected ? LIGHT : 0xFF202033);
            }

            if (selected) {
                drawRect(guiX + 5, y + 2,
                        guiX + 8, y + 27, PURPLE);
            }

            fontRendererObj.drawString(
                    formatCategory(categories[i].name()),
                    guiX + 15, y + 11,
                    selected ? WHITE : GRAY);
        }
    }

    private List<Module> getCurrentModules() {
        return CustomClient.getInstance()
                .getModuleManager()
                .getModulesByCategory(categories[selectedCategory]);
    }

    private void drawModules(int contentY, int bottom,
                             int mouseX, int mouseY) {
        List<Module> modules = getCurrentModules();
        int startY = contentY + 31;
        int visibleRows = Math.max(0, (bottom - 22 - startY) / 29);

        moduleScroll = Math.max(0, Math.min(
                moduleScroll, modules.size() - visibleRows));

        for (int i = moduleScroll; i < modules.size(); i++) {
            int y = startY + (i - moduleScroll) * 29;

            if (y + 29 > bottom - 20) {
                break;
            }

            Module module = modules.get(i);
            boolean selected = module == selectedModule;
            boolean hovered = inside(mouseX, mouseY,
                    guiX + 116, y, 180, 29);

            if (selected || hovered) {
                drawRect(guiX + 116, y + 2,
                        guiX + 296, y + 27,
                        selected ? LIGHT : 0xFF202033);
            }

            fontRendererObj.drawString(module.getName(),
                    guiX + 124, y + 11,
                    module.isToggled() ? PURPLE : WHITE);

            drawRect(guiX + 277, y + 11,
                    guiX + 284, y + 18,
                    module.isToggled() ? GREEN : 0xFF555568);

            if (module == bindingModule) {
                fontRendererObj.drawString("...",
                        guiX + 258, y + 11, PURPLE);
            }
        }
    }

    private void drawSettings(int contentY, int bottom) {
        int x = guiX + 308;
        int widthAvailable = GUI_WIDTH - 324;
        int startY = contentY + 32;

        if (selectedModule == null) {
            fontRendererObj.drawString("Select a module",
                    x + 8, startY + 12, GRAY);
            fontRendererObj.drawString("to view settings",
                    x + 8, startY + 26, GRAY);
            return;
        }

        fontRendererObj.drawString(selectedModule.getName(),
                x + 8, startY, WHITE);

        fontRendererObj.drawString(
                selectedModule.isToggled() ? "ENABLED" : "DISABLED",
                x + 8, startY + 13,
                selectedModule.isToggled() ? GREEN : GRAY);

        int bindY = startY + 30;

        drawRect(x + 5, bindY, x + widthAvailable,
                bindY + 22, bindingModule == selectedModule
                        ? DARK_PURPLE : LIGHT);

        String bindText = bindingModule == selectedModule
                ? "Press a key..."
                : "Bind: " + selectedModule.getKeyName();

        fontRendererObj.drawString(bindText,
                x + 10, bindY + 7,
                bindingModule == selectedModule ? WHITE : PURPLE);

        int modeY = bindY + 26;

        drawRect(x + 5, modeY, x + widthAvailable,
                modeY + 22, LIGHT);

        fontRendererObj.drawString(
                "Bind Mode: " + selectedModule.getBindMode().name(),
                x + 10, modeY + 7, WHITE);

        List<Setting> settings = selectedModule.getSettings();
        int settingsY = modeY + 30;
        int rowHeight = 47;

        int visibleRows = Math.max(0,
                (bottom - 22 - settingsY) / rowHeight);

        settingScroll = Math.max(0, Math.min(
                settingScroll, settings.size() - visibleRows));

        for (int i = settingScroll; i < settings.size(); i++) {
            int y = settingsY + (i - settingScroll) * rowHeight;

            if (y + rowHeight > bottom - 20) {
                break;
            }

            Setting setting = settings.get(i);

            fontRendererObj.drawString(setting.getName(),
                    x + 8, y + 2, WHITE);

            if (setting instanceof NumberSetting) {
                drawNumberSetting((NumberSetting) setting,
                        x + 8, y + 17, widthAvailable - 16);
            } else if (setting instanceof ModeSetting) {
                drawModeSetting((ModeSetting) setting,
                        x + 8, y + 17, widthAvailable - 16);
            } else if (setting instanceof BooleanSetting) {
                drawBooleanSetting((BooleanSetting) setting,
                        x + 8, y + 17, widthAvailable - 16);
            }
        }
    }

    private void drawBooleanSetting(BooleanSetting setting,
                                    int x, int y, int availableWidth) {
        boolean enabled = setting.getValue();
        int boxX = x + availableWidth - 38;

        drawRect(boxX, y, boxX + 38, y + 16,
                enabled ? DARK_PURPLE : 0xFF38384C);

        fontRendererObj.drawString(enabled ? "ON" : "OFF",
                boxX + 9, y + 4, enabled ? GREEN : GRAY);
    }

    private void drawNumberSetting(NumberSetting setting,
                                   int x, int y, int barWidth) {
        double min = setting.getMin();
        double max = setting.getMax();
        double range = max - min;

        double percentage = range <= 0 ? 0
                : (setting.getValue() - min) / range;

        percentage = Math.max(0, Math.min(1, percentage));

        drawRect(x, y + 13, x + barWidth, y + 18, 0xFF38384C);
        drawRect(x, y + 13,
                x + (int) (barWidth * percentage), y + 18, PURPLE);

        String value = formatNumber(setting.getValue());

        fontRendererObj.drawString(value,
                x + barWidth - fontRendererObj.getStringWidth(value),
                y, PURPLE);
    }

    private void drawModeSetting(ModeSetting setting,
                                 int x, int y, int barWidth) {
        drawRect(x, y, x + barWidth, y + 21, LIGHT);
        fontRendererObj.drawString("<", x + 6, y + 7, PURPLE);
        fontRendererObj.drawString(setting.getValue(),
                x + 18, y + 7, WHITE);
        fontRendererObj.drawString(">", x + barWidth - 12,
                y + 7, PURPLE);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button)
            throws IOException {
        super.mouseClicked(mouseX, mouseY, button);

        if (button == 0 && inside(mouseX, mouseY,
                guiX, guiY, GUI_WIDTH, 38)) {
            dragging = true;
            dragOffsetX = mouseX - guiX;
            dragOffsetY = mouseY - guiY;
            return;
        }

        int contentY = guiY + 39;
        int bottom = guiY + GUI_HEIGHT;

        if (mouseY < contentY + 31 || mouseY >= bottom - 20) {
            return;
        }

        if (mouseX >= guiX && mouseX < guiX + 112) {
            int index = (mouseY - (contentY + 31)) / 29;

            if (index >= 0 && index < categories.length) {
                selectedCategory = index;
                selectedModule = null;
                moduleScroll = 0;
                settingScroll = 0;
            }
            return;
        }

        if (mouseX >= guiX + 112 && mouseX < guiX + 300) {
            List<Module> modules = getCurrentModules();
            int row = (mouseY - (contentY + 31)) / 29;
            int index = moduleScroll + row;

            if (index >= 0 && index < modules.size()) {
                Module module = modules.get(index);

                if (button == 0) {
                    module.toggle();
                }

                selectedModule = module;
                settingScroll = 0;
            }
            return;
        }

        if (selectedModule == null) {
            return;
        }

        int x = guiX + 308;
        int widthAvailable = GUI_WIDTH - 324;
        int startY = contentY + 32;
        int bindY = startY + 30;
        int modeY = bindY + 26;

        if (inside(mouseX, mouseY, x + 5, bindY,
                widthAvailable - 5, 22)) {
            bindingModule = selectedModule;
            return;
        }

        if (inside(mouseX, mouseY, x + 5, modeY,
                widthAvailable - 5, 22)) {
            selectedModule.setBindMode(
                    selectedModule.getBindMode() == Module.BindMode.TOGGLE
                            ? Module.BindMode.HOLD
                            : Module.BindMode.TOGGLE);
            return;
        }

        List<Setting> settings = selectedModule.getSettings();
        int settingsY = modeY + 30;
        int rowHeight = 47;

        int row = (mouseY - settingsY) / rowHeight;
        int index = settingScroll + row;

        if (index < 0 || index >= settings.size()) {
            return;
        }

        Setting setting = settings.get(index);
        int localY = (mouseY - settingsY) % rowHeight;

        if (setting instanceof NumberSetting && button == 0
                && localY >= 17 && localY <= 39) {
            activeSlider = (NumberSetting) setting;
            draggingSlider = true;
            updateSlider(mouseX, x + 8, activeSlider);
        } else if (setting instanceof ModeSetting
                && (button == 0 || button == 1)) {
            ((ModeSetting) setting).nextMode();
        } else if (setting instanceof BooleanSetting
                && button == 0 && localY >= 12 && localY <= 37) {
            ((BooleanSetting) setting).toggle();
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode)
            throws IOException {
        if (bindingModule != null) {
            if (keyCode == Keyboard.KEY_ESCAPE) {
                bindingModule = null;
                return;
            }

            if (keyCode == Keyboard.KEY_BACK
                    || keyCode == Keyboard.KEY_DELETE) {
                bindingModule.setKeyCode(0);
                bindingModule = null;
                return;
            }

            if (keyCode != Keyboard.KEY_NONE) {
                bindingModule.setKeyCode(keyCode);
                bindingModule = null;
            }
            return;
        }

        if (keyCode == Keyboard.KEY_ESCAPE
                || keyCode == Keyboard.KEY_RSHIFT) {
            mc.displayGuiScreen(null);
            return;
        }

        super.keyTyped(typedChar, keyCode);
    }

    private void updateSlider(int mouseX, int x,
                              NumberSetting setting) {
        int barWidth = GUI_WIDTH - 340;

        double percentage = (double) (mouseX - x) / barWidth;
        percentage = Math.max(0, Math.min(1, percentage));

        setting.setValue(setting.getMin()
                + percentage * (setting.getMax() - setting.getMin()));
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY,
                                  int button, long timeSinceLastClick) {
        super.mouseClickMove(mouseX, mouseY, button, timeSinceLastClick);

        if (dragging) {
            guiX = mouseX - dragOffsetX;
            guiY = mouseY - dragOffsetY;
        }

        if (draggingSlider && activeSlider != null) {
            updateSlider(mouseX, guiX + 316, activeSlider);
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        dragging = false;
        draggingSlider = false;
        activeSlider = null;
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();

        int wheel = Mouse.getEventDWheel();
        if (wheel == 0) {
            return;
        }

        int mouseX = Mouse.getEventX() * width / mc.displayWidth;
        int mouseY = height
                - Mouse.getEventY() * height / mc.displayHeight - 1;

        if (mouseX >= guiX + 112 && mouseX < guiX + 300
                && mouseY >= guiY + 70
                && mouseY < guiY + GUI_HEIGHT - 20) {
            moduleScroll += wheel > 0 ? -1 : 1;
        } else if (mouseX >= guiX + 300
                && mouseX < guiX + GUI_WIDTH
                && selectedModule != null) {
            settingScroll += wheel > 0 ? -1 : 1;
        }
    }

    private boolean inside(int mouseX, int mouseY,
                           int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w
                && mouseY >= y && mouseY < y + h;
    }

    private String formatCategory(String name) {
        String lower = name.toLowerCase();

        if (lower.length() == 0) {
            return name;
        }

        return Character.toUpperCase(lower.charAt(0))
                + lower.substring(1);
    }

    private String formatNumber(double value) {
        if (value == (int) value) {
            return String.valueOf((int) value);
        }

        return String.format(java.util.Locale.US, "%.1f", value);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
