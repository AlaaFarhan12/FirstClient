
package com.customclient.module;

import com.customclient.CustomClient;
import com.customclient.setting.Setting;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    private final List<Setting> settings = new ArrayList<Setting>();

    private final String name;
    private final String description;
    private final Category category;

    private int keyCode;
    private boolean toggled;

    private BindMode bindMode = BindMode.TOGGLE;
    private boolean bindWasDown = false;

    protected final Minecraft mc = Minecraft.getMinecraft();

    public enum BindMode {
        TOGGLE,
        HOLD
    }

    public Module(
            String name,
            String description,
            Category category,
            int keyCode
    ) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.keyCode = keyCode;
        this.toggled = false;
    }

    public void toggle() {
        setToggled(!this.toggled);
    }

    public void setToggled(boolean toggled) {
        if (this.toggled == toggled) {
            return;
        }

        this.toggled = toggled;

        if (this.toggled) {
            onEnable();
            sendToggleMessage(true);
        } else {
            onDisable();
            sendToggleMessage(false);
        }
    }

    private void sendToggleMessage(boolean enabled) {
        if (mc.thePlayer == null) {
            return;
        }

        String status = enabled ? "ENABLED" : "DISABLED";
        EnumChatFormatting color = enabled
                ? EnumChatFormatting.GREEN
                : EnumChatFormatting.RED;

        mc.thePlayer.addChatMessage(
                new ChatComponentText(
                        EnumChatFormatting.DARK_PURPLE
                                + "[Vampire Client] "
                                + EnumChatFormatting.WHITE
                                + name + " "
                                + color + status
                )
        );
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onTick() {
    }

    public void onRender2D() {
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public int getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(int keyCode) {
        this.keyCode = Math.max(0, keyCode);
        bindWasDown = false;
    }

    public String getKeyName() {
        if (keyCode <= 0) {
            return "NONE";
        }

        String name = Keyboard.getKeyName(keyCode);
        return name == null ? "NONE" : name;
    }

    public BindMode getBindMode() {
        return bindMode;
    }

    public void setBindMode(BindMode bindMode) {
        this.bindMode = bindMode == null
                ? BindMode.TOGGLE
                : bindMode;

        bindWasDown = false;
    }

    public boolean isBindDown() {
        return keyCode > 0 && Keyboard.isKeyDown(keyCode);
    }

    public boolean wasBindDown() {
        return bindWasDown;
    }

    public void setBindWasDown(boolean bindWasDown) {
        this.bindWasDown = bindWasDown;
    }

    public boolean isToggled() {
        return toggled;
    }

    public List<Setting> getSettings() {
        return settings;
    }

    public void addSetting(Setting setting) {
        if (setting != null) {
            settings.add(setting);
        }
    }
}
