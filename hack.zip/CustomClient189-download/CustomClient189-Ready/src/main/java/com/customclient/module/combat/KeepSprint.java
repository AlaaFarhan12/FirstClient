
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

public class KeepSprint extends Module {

    private final ModeSetting mode = new ModeSetting(
            "Mode", "Legit", "Legit", "Blatant", "Custom"
    );

    private final NumberSetting sprintFactor =
            new NumberSetting("Sprint Factor", 100.0, 0.0, 100.0);

    private boolean wasSprinting;

    public KeepSprint() {
        super("KeepSprint", "Sprint behavior settings",
                Category.COMBAT, 0);

        addSetting(mode);
        addSetting(sprintFactor);
    }

    @Override
    public void onEnable() {
        wasSprinting = false;
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null || mc.theWorld == null
                || mc.currentScreen != null) {
            wasSprinting = false;
            return;
        }

        if (!mc.thePlayer.isSprinting()) {
            wasSprinting = false;
            return;
        }

        wasSprinting = true;

        if ("Legit".equalsIgnoreCase(mode.getValue())) {
            // Leave vanilla sprint behavior unchanged.
            return;
        }

        if ("Blatant".equalsIgnoreCase(mode.getValue())) {
            mc.thePlayer.setSprinting(true);
            return;
        }

        if ("Custom".equalsIgnoreCase(mode.getValue())) {
            double factor = sprintFactor.getValue();

            if (factor > 0.0 && wasSprinting) {
                mc.thePlayer.setSprinting(true);
            }
        }
    }

    @Override
    public void onDisable() {
        wasSprinting = false;
    }

    public String getMode() {
        return mode.getValue();
    }

    public double getSprintFactor() {
        return sprintFactor.getValue();
    }
}
