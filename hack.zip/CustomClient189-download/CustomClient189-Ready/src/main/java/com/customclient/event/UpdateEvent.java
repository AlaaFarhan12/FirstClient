package com.customclient.event;

public class UpdateEvent {
}
