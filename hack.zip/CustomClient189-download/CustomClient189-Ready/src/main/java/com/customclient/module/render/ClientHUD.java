
package com.customclient.module.render;

import com.customclient.CustomClient;
import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.NumberSetting;
import com.customclient.setting.ModeSetting;

import net.minecraft.client.gui.Gui;

import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ClientHUD extends Module {

    private final NumberSetting xPosition =
            new NumberSetting("X Position", 6, 0, 500);

    private final NumberSetting yPosition =
            new NumberSetting("Y Position", 6, 0, 300);

    private final BooleanSetting background =
            new BooleanSetting("Background", true);

    private final BooleanSetting showTitle =
            new BooleanSetting("Show Title", true);

    private final ModeSetting colorMode =
            new ModeSetting(
                    "Color",
                    "Purple",
                    "White",
                    "Green",
                    "Blue",
                    "Red"
            );

    public ClientHUD() {
        super(
                "HUD",
                "Customizable enabled modules list",
                Category.HUD,
                Keyboard.KEY_NONE
        );

        addSetting(xPosition);
        addSetting(yPosition);
        addSetting(background);
        addSetting(showTitle);
        addSetting(colorMode);

        // HUD مفعّل افتراضياً عند أول تشغيل.
        setToggled(true);
    }

    @Override
    public void onRender2D() {
        if (mc.thePlayer == null || mc.theWorld == null) {
            return;
        }

        int x = (int) xPosition.getValue();
        int y = (int) yPosition.getValue();

        int screenWidth = mc.displayWidth;
        int color = getSelectedColor();

        List<Module> enabledModules = new ArrayList<Module>();

        if (CustomClient.getInstance() != null
                && CustomClient.getInstance().getModuleManager() != null) {

            for (Module module : CustomClient.getInstance()
                    .getModuleManager().getModules()) {

                if (module != this && module.isToggled()) {
                    enabledModules.add(module);
                }
            }
        }

        Collections.sort(
                enabledModules,
                new Comparator<Module>() {
                    @Override
                    public int compare(Module a, Module b) {
                        return Integer.compare(
                                mc.fontRendererObj.getStringWidth(b.getName()),
                                mc.fontRendererObj.getStringWidth(a.getName())
                        );
                    }
                }
        );

        int lineHeight = mc.fontRendererObj.FONT_HEIGHT + 4;
        int currentY = y;

        if (showTitle.getValue()) {
            currentY = drawEntry(
                    "CUSTOMCLIENT",
                    x,
                    currentY,
                    color
            ) + 2;
        }

        for (Module module : enabledModules) {
            currentY = drawEntry(
                    module.getName(),
                    x,
                    currentY,
                    0xFFFFFFFF
            );
        }
    }

    private int drawEntry(String text, int x, int y, int color) {
        int padding = 4;
        int textWidth = mc.fontRendererObj.getStringWidth(text);
        int height = mc.fontRendererObj.FONT_HEIGHT + 3;

        if (background.getValue()) {
            Gui.drawRect(
                    x - padding,
                    y - 1,
                    x + textWidth + padding,
                    y + height,
                    0xB5101220
            );

            Gui.drawRect(
                    x - padding,
                    y - 1,
                    x - padding + 2,
                    y + height,
                    getSelectedColor()
            );
        }

        mc.fontRendererObj.drawStringWithShadow(
                text,
                x,
                y,
                color
        );

        return y + height + 2;
    }

    private int getSelectedColor() {
        String mode = colorMode.getValue();

        if ("White".equals(mode)) {
            return 0xFFFFFFFF;
        }

        if ("Green".equals(mode)) {
            return 0xFF65E6AC;
        }

        if ("Blue".equals(mode)) {
            return 0xFF55AAFF;
        }

        if ("Red".equals(mode)) {
            return 0xFFFF5555;
        }

        return 0xFF9B70FF;
    }
}
