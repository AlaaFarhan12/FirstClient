
package com.customclient.setting;

import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting {

    private final List<String> modes;
    private int index;

    public ModeSetting(String name, String... modes) {
        super(name);

        if (modes == null || modes.length == 0) {
            throw new IllegalArgumentException(
                    "At least one mode is required"
            );
        }

        this.modes = Arrays.asList(modes);
        this.index = 0;
    }

    public String getValue() {
        return modes.get(index);
    }

    public List<String> getModes() {
        return modes;
    }

    public void nextMode() {
        index = (index + 1) % modes.size();
    }

    public void setValue(String mode) {
        int newIndex = modes.indexOf(mode);

        if (newIndex != -1) {
            index = newIndex;
        }
    }
}
