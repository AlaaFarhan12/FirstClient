
package com.customclient.module.movement;

import com.customclient.module.Category;
import com.customclient.module.Module;

import net.minecraft.client.settings.KeyBinding;

public class ToggleSprint extends Module {

    public ToggleSprint() {
        super(
                "ToggleSprint",
                "Automatically sprints while moving forward",
                Category.MOVEMENT,
                0
        );
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null
                || mc.gameSettings == null
                || mc.currentScreen != null
                || !mc.inGameHasFocus) {
            releaseSprintKey();
            return;
        }

        boolean movingForward = mc.thePlayer.moveForward > 0.0F;
        boolean notSneaking = !mc.thePlayer.isSneaking();

        boolean enoughFood =
                mc.thePlayer.capabilities.isCreativeMode
                        || mc.thePlayer.getFoodStats().getFoodLevel() > 6;

        boolean canSprint =
                movingForward && notSneaking && enoughFood;

        KeyBinding.setKeyBindState(
                mc.gameSettings.keyBindSprint.getKeyCode(),
                canSprint
        );
    }

    @Override
    public void onDisable() {
        releaseSprintKey();
    }

    private void releaseSprintKey() {
        if (mc != null && mc.gameSettings != null) {
            KeyBinding.setKeyBindState(
                    mc.gameSettings.keyBindSprint.getKeyCode(),
                    false
            );
        }
    }
}
