
package com.customclient.module;

import com.customclient.module.movement.ToggleSprint;
import com.customclient.module.render.Fullbright;
import com.customclient.module.render.ClientHUD;

import com.customclient.module.combat.AutoClicker;
import com.customclient.module.combat.AutoBlock;
import com.customclient.module.combat.AutoUse;
import com.customclient.module.combat.AimAssist;
import com.customclient.module.combat.Criticals;
import com.customclient.module.combat.HitSelect;
import com.customclient.module.combat.KeepSprint;
import com.customclient.module.combat.Reach;
import com.customclient.module.combat.TargetStrafe;
import com.customclient.module.combat.Velocity;
import com.customclient.module.combat.WTap;
import com.customclient.module.combat.KillAura;
import com.customclient.module.combat.NoHitDelay;

import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.lwjgl.input.Keyboard;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<Module>();
    private final Minecraft mc = Minecraft.getMinecraft();

    public ModuleManager() {
        registerModules();
    }

    private void registerModules() {
        addModule(new ToggleSprint());

        addModule(new Fullbright());
        addModule(new ClientHUD());

        addModule(new AutoClicker());
        addModule(new AutoBlock());
        addModule(new AutoUse());
        addModule(new AimAssist());
        addModule(new Criticals());
        addModule(new HitSelect());
        addModule(new KeepSprint());
        addModule(new Reach());
        addModule(new TargetStrafe());
        addModule(new Velocity());
        addModule(new WTap());
        addModule(new KillAura());
        addModule(new NoHitDelay());
    }

    private void addModule(Module module) {
        if (module != null && getModule(module.getName()) == null) {
            modules.add(module);
        }
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    public Module getModule(String name) {
        if (name == null) {
            return null;
        }

        for (Module module : modules) {
            if (module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }

        return null;
    }

    public <T extends Module> T getModule(Class<T> clazz) {
        if (clazz == null) {
            return null;
        }

        for (Module module : modules) {
            if (clazz.isInstance(module)) {
                return clazz.cast(module);
            }
        }

        return null;
    }

    public List<Module> getModulesByCategory(Category category) {
        return modules.stream()
                .filter(module -> module.getCategory() == category)
                .collect(Collectors.toList());
    }

    /**
     * Called when a keyboard key is pressed.
     * TOGGLE modules change state on each key press.
     */
    public void onKeyPressed(int keyCode) {
        if (keyCode <= 0 || mc.currentScreen != null) {
            return;
        }

        for (Module module : modules) {
            if (module.getKeyCode() != keyCode) {
                continue;
            }

            if (module.getBindMode() == Module.BindMode.TOGGLE) {
                module.toggle();
            }
        }
    }

    /**
     * HOLD modules stay enabled only while their key is held.
     */
    private void updateHoldBinds() {
        boolean canReadKeyboard = mc.thePlayer != null
                && mc.theWorld != null
                && mc.currentScreen == null
                && Keyboard.isCreated()
                && mc.inGameHasFocus;

        for (Module module : modules) {
            if (module.getBindMode() != Module.BindMode.HOLD) {
                continue;
            }

            boolean keyDown = canReadKeyboard
                    && module.getKeyCode() > 0
                    && Keyboard.isKeyDown(module.getKeyCode());

            module.setBindWasDown(keyDown);

            if (module.isToggled() != keyDown) {
                module.setToggled(keyDown);
            }
        }
    }

    public void onTick() {
        updateHoldBinds();

        for (Module module : modules) {
            if (!module.isToggled()) {
                continue;
            }

            try {
                module.onTick();
            } catch (Exception e) {
                System.err.println(
                        "[Vampire Client] Tick error in "
                                + module.getName()
                );
                e.printStackTrace();
            }
        }
    }

    public void onRender2D() {
        for (Module module : modules) {
            if (!module.isToggled()) {
                continue;
            }

            try {
                module.onRender2D();
            } catch (Exception e) {
                System.err.println(
                        "[Vampire Client] Render error in "
                                + module.getName()
                );
                e.printStackTrace();
            }
        }
    }
}
