
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;

public class AutoClicker extends Module {

    private final NumberSetting cps =
            new NumberSetting("CPS", 10, 1, 100);

    private final NumberSetting minCps =
            new NumberSetting("Min CPS", 8, 1, 100);

    private final NumberSetting maxCps =
            new NumberSetting("Max CPS", 12, 1, 100);

    private final ModeSetting button =
            new ModeSetting("Button", "Left", "Right");

    private final ModeSetting cpsMode =
            new ModeSetting("CPS Mode", "Fixed", "Random");

    private final ModeSetting timingMode =
            new ModeSetting("Timing", "Tick", "Render", "Timer");

    private final BooleanSetting requireHold =
            new BooleanSetting("Hold To Track", true);

    private final BooleanSetting stopOnGui =
            new BooleanSetting("Stop On GUI", true);

    private final Random random = new Random();
    private final Deque<Long> clickTimes = new ArrayDeque<Long>();

    private long lastClickTime;
    private long lastInterval;
    private int currentCps;
    private boolean previousButtonDown;

    public AutoClicker() {
        super(
                "AutoClicker",
                "Local click timing trainer and CPS statistics",
                Category.COMBAT,
                Keyboard.KEY_NONE
        );

        addSetting(cps);
        addSetting(minCps);
        addSetting(maxCps);
        addSetting(button);
        addSetting(cpsMode);
        addSetting(timingMode);
        addSetting(requireHold);
        addSetting(stopOnGui);
    }

    @Override
    public void onEnable() {
        resetStats();
    }

    @Override
    public void onDisable() {
        resetStats();
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null || mc.theWorld == null) {
            resetStats();
            return;
        }

        if (stopOnGui.getValue() && mc.currentScreen != null) {
            previousButtonDown = false;
            return;
        }

        if (timingMode.getValue().equals("Render")) {
            return;
        }

        trackPhysicalClick();
    }

    @Override
    public void onRender2D() {
        if (!isToggled() || mc.thePlayer == null) {
            return;
        }

        if (timingMode.getValue().equals("Render")) {
            trackPhysicalClick();
        }

        updateCps();

        // Training statistics can be read through the getters below.
        // No automated mouse clicks are generated.
    }

    private void trackPhysicalClick() {
        int mouseButton = button.getValue().equals("Right") ? 1 : 0;
        boolean down = Mouse.isButtonDown(mouseButton);

        if (requireHold.getValue() && !down) {
            previousButtonDown = false;
            return;
        }

        // Count a physical press transition, not a generated click.
        if (down && !previousButtonDown) {
            long now = System.currentTimeMillis();

            if (lastClickTime > 0L) {
                lastInterval = now - lastClickTime;
            }

            lastClickTime = now;
            clickTimes.addLast(now);
        }

        previousButtonDown = down;
        updateCps();
    }

    private void updateCps() {
        long now = System.currentTimeMillis();

        while (!clickTimes.isEmpty()
                && now - clickTimes.peekFirst() >= 1000L) {
            clickTimes.removeFirst();
        }

        currentCps = clickTimes.size();
    }

    private void resetStats() {
        clickTimes.clear();
        lastClickTime = 0L;
        lastInterval = 0L;
        currentCps = 0;
        previousButtonDown = false;
    }

    public int getCurrentCps() {
        updateCps();
        return currentCps;
    }

    public long getLastInterval() {
        return lastInterval;
    }

    public NumberSetting getCpsSetting() {
        return cps;
    }

    public NumberSetting getMinCpsSetting() {
        return minCps;
    }

    public NumberSetting getMaxCpsSetting() {
        return maxCps;
    }

    public ModeSetting getButtonSetting() {
        return button;
    }

    public ModeSetting getCpsModeSetting() {
        return cpsMode;
    }

    public ModeSetting getTimingModeSetting() {
        return timingMode;
    }

    public BooleanSetting getRequireHoldSetting() {
        return requireHold;
    }

    public BooleanSetting getStopOnGuiSetting() {
        return stopOnGui;
    }
}
