
package com.customclient.module.combat;

import com.customclient.module.Category;
import com.customclient.module.Module;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;

public class TargetStrafe extends Module {

    private final ModeSetting mode = new ModeSetting(
            "Mode", "Legit", "Legit", "Blatant", "Circle"
    );

    private final NumberSetting radius =
            new NumberSetting("Radius", 2.5, 1.0, 5.0);

    private final NumberSetting speed =
            new NumberSetting("Speed", 1.0, 0.1, 3.0);

    private final BooleanSetting jump =
            new BooleanSetting("Jump", false);

    private final BooleanSetting autoDirection =
            new BooleanSetting("Auto Direction", true);

    private Entity target;
    private int direction = 1;
    private long lastDirectionChange;

    public TargetStrafe() {
        super("TargetStrafe", "Target movement configuration",
                Category.COMBAT, 0);

        addSetting(mode);
        addSetting(radius);
        addSetting(speed);
        addSetting(jump);
        addSetting(autoDirection);
    }

    @Override
    public void onEnable() {
        target = null;
        direction = 1;
        lastDirectionChange = System.currentTimeMillis();
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null
                || mc.theWorld == null
                || mc.currentScreen != null) {
            target = null;
            return;
        }

        target = findTarget();

        if (target == null) {
            return;
        }

        if (autoDirection.getValue()
                && System.currentTimeMillis() - lastDirectionChange > 2000L) {
            direction *= -1;
            lastDirectionChange = System.currentTimeMillis();
        }

        if (jump.getValue() && mc.thePlayer.onGround) {
            mc.thePlayer.jump();
        }

        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        double currentDistance = Math.sqrt(dx * dx + dz * dz);

        if (currentDistance < 0.001) {
            return;
        }

        double desiredRadius = radius.getValue();
        double radialError = currentDistance - desiredRadius;

        double radialX = dx / currentDistance;
        double radialZ = dz / currentDistance;

        double tangentX = -radialZ * direction;
        double tangentZ = radialX * direction;

        double radialStrength = 0.0;

        if ("Circle".equalsIgnoreCase(mode.getValue())) {
            radialStrength = radialError * 0.15;
        } else if ("Blatant".equalsIgnoreCase(mode.getValue())) {
            radialStrength = radialError * 0.30;
        } else {
            radialStrength = radialError * 0.10;
        }

        double moveX = tangentX + radialX * radialStrength;
        double moveZ = tangentZ + radialZ * radialStrength;

        double length = Math.sqrt(moveX * moveX + moveZ * moveZ);

        if (length > 0.001) {
            moveX /= length;
            moveZ /= length;
        }

        double movementSpeed = speed.getValue() * 0.15;

        mc.thePlayer.motionX = moveX * movementSpeed;
        mc.thePlayer.motionZ = moveZ * movementSpeed;
    }

    private Entity findTarget() {
        MovingObjectPosition hit = mc.objectMouseOver;

        if (hit == null
                || hit.typeOfHit
                != MovingObjectPosition.MovingObjectType.ENTITY) {
            return null;
        }

        Entity entity = hit.entityHit;

        if (entity == null || entity == mc.thePlayer || entity.isDead) {
            return null;
        }

        if (entity instanceof EntityPlayer
                && ((EntityPlayer) entity).getHealth() <= 0.0F) {
            return null;
        }

        return entity;
    }

    @Override
    public void onDisable() {
        target = null;

        // Avoid leaving horizontal motion controlled by this module.
        if (mc.thePlayer != null) {
            mc.thePlayer.motionX = 0.0;
            mc.thePlayer.motionZ = 0.0;
        }
    }

    public String getMode() {
        return mode.getValue();
    }

    public double getRadius() {
        return radius.getValue();
    }

    public double getSpeed() {
        return speed.getValue();
    }

    public boolean isJumpEnabled() {
        return jump.getValue();
    }

    public boolean isAutoDirectionEnabled() {
        return autoDirection.getValue();
    }
}
