
package com.customclient.setting;

public class NumberSetting extends Setting {

    private double value;
    private final double min;
    private final double max;

    public NumberSetting(String name, double value,
                         double min, double max) {
        super(name);
        this.min = min;
        this.max = max;
        setValue(value);
    }

    public double getValue() {
        return value;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public void setValue(double value) {
        this.value = Math.max(min, Math.min(max, value));
    }
}
