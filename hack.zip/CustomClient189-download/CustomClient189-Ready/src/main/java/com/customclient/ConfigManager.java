
package com.customclient;

import com.customclient.module.Module;
import com.customclient.module.ModuleManager;
import com.customclient.setting.BooleanSetting;
import com.customclient.setting.ModeSetting;
import com.customclient.setting.NumberSetting;
import com.customclient.setting.Setting;

import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public final class ConfigManager {

    private static final String CONFIG_FILE_NAME =
            "customclient.properties";

    private static final String CONFIG_FOLDER_NAME =
            "config";

    private ConfigManager() {
    }

    private static File getConfigFile() {
        File folder = new File(
                Minecraft.getMinecraft().mcDataDir,
                CONFIG_FOLDER_NAME
        );

        if (!folder.exists() && !folder.mkdirs()) {
            System.err.println(
                    "[CustomClient] Could not create config folder."
            );
        }

        return new File(folder, CONFIG_FILE_NAME);
    }

    public static void load(ModuleManager manager) {
        if (manager == null) {
            return;
        }

        File file = getConfigFile();

        if (!file.isFile()) {
            return;
        }

        Properties properties = new Properties();

        try (FileInputStream input =
                     new FileInputStream(file)) {

            properties.load(input);

            for (Module module : manager.getModules()) {
                String prefix = "module."
                        + module.getName() + ".";

                loadModule(properties, module, prefix);
            }

        } catch (IOException e) {
            System.err.println(
                    "[CustomClient] Load error: "
                            + e.getMessage()
            );
        }
    }

    private static void loadModule(
            Properties properties,
            Module module,
            String prefix) {

        String enabled = properties.getProperty(
                prefix + "enabled"
        );

        if (enabled != null) {
            module.setToggled(
                    Boolean.parseBoolean(enabled)
            );
        }

        String key = properties.getProperty(
                prefix + "key"
        );

        if (key != null) {
            try {
                module.setKeyCode(
                        Integer.parseInt(key)
                );
            } catch (NumberFormatException e) {
                System.err.println(
                        "[CustomClient] Invalid key for "
                                + module.getName()
                );
            }
        }

        String bindMode = properties.getProperty(
                prefix + "bindMode"
        );

        if (bindMode != null) {
            try {
                module.setBindMode(
                        Module.BindMode.valueOf(
                                bindMode.trim().toUpperCase()
                        )
                );
            } catch (IllegalArgumentException e) {
                System.err.println(
                        "[CustomClient] Invalid bind mode for "
                                + module.getName()
                );
            }
        }

        for (Setting setting : module.getSettings()) {
            String settingKey = prefix
                    + "setting."
                    + setting.getName();

            String value = properties.getProperty(settingKey);

            if (value == null) {
                continue;
            }

            try {
                if (setting instanceof BooleanSetting) {
                    if ("true".equalsIgnoreCase(value)
                            || "false".equalsIgnoreCase(value)) {
                        ((BooleanSetting) setting).setValue(
                                Boolean.parseBoolean(value)
                        );
                    }
                } else if (setting instanceof NumberSetting) {
                    double number = Double.parseDouble(value);

                    if (Double.isNaN(number)
                            || Double.isInfinite(number)) {
                        continue;
                    }

                    ((NumberSetting) setting).setValue(number);

                } else if (setting instanceof ModeSetting) {
                    ((ModeSetting) setting).setValue(value);
                }

            } catch (RuntimeException e) {
                System.err.println(
                        "[CustomClient] Invalid setting: "
                                + setting.getName()
                );
            }
        }
    }

    public static void save(ModuleManager manager) {
        if (manager == null) {
            return;
        }

        Properties properties = new Properties();

        for (Module module : manager.getModules()) {
            String prefix = "module."
                    + module.getName() + ".";

            properties.setProperty(
                    prefix + "enabled",
                    String.valueOf(module.isToggled())
            );

            properties.setProperty(
                    prefix + "key",
                    String.valueOf(module.getKeyCode())
            );

            properties.setProperty(
                    prefix + "bindMode",
                    module.getBindMode().name()
            );

            for (Setting setting : module.getSettings()) {
                String settingKey = prefix
                        + "setting."
                        + setting.getName();

                if (setting instanceof BooleanSetting) {
                    properties.setProperty(
                            settingKey,
                            String.valueOf(
                                    ((BooleanSetting) setting).getValue()
                            )
                    );

                } else if (setting instanceof NumberSetting) {
                    properties.setProperty(
                            settingKey,
                            String.valueOf(
                                    ((NumberSetting) setting).getValue()
                            )
                    );

                } else if (setting instanceof ModeSetting) {
                    properties.setProperty(
                            settingKey,
                            ((ModeSetting) setting).getValue()
                    );
                }
            }
        }

        File file = getConfigFile();

        try (FileOutputStream output =
                     new FileOutputStream(file)) {

            properties.store(
                    output,
                    "Vampire Client Configuration"
            );

        } catch (IOException e) {
            System.err.println(
                    "[CustomClient] Save error: "
                            + e.getMessage()
            );
        }
    }
}
